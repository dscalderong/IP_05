﻿using System;


namespace Actividad_semana12
{
    class TrianguloRectangulo
    {


        private double catetoA;
        private double anguloOPuestoA;
        public TrianguloRectangulo(double cateto, double angulo)
        {
            catetoA = cateto;
            anguloOPuestoA = angulo;
        }
        public double ObtenerCatetoA()
        {
            return Math.Round(catetoA, 3);
        }
        public double ObtenerCatetoB()
        {
            double catetoB = catetoA * Math.Tan(anguloOPuestoA);
            return Math.Round(catetoB, 3);
        }
        public double ObtenerHipotenusa()
        {
            double hipotenusa = Math.Sqrt(Math.Pow(catetoA, 2) + Math.Pow(ObtenerCatetoB(), 2));
            return Math.Round(hipotenusa, 3);
        }
        public double ObtenerAnguloOPuestoA()
        {
            return Math.Round(anguloOPuestoA, 3);
        }
        public double ObtenerAnguloOPuestoB()
        {
            double anguloOPuestoB = 90 - anguloOPuestoA;
            return Math.Round(anguloOPuestoB, 3);
        }
        public double ObtenerArea()
        {
            double area = (catetoA * ObtenerCatetoB()) / 2;
            return Math.Round(area, 3);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Insertar valor del cateto A: ");
            double cateto = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Insertar valor para angulo opuesto A: ");
            double angulo = Convert.ToDouble(Console.ReadLine());

            TrianguloRectangulo triangulo = new TrianguloRectangulo(cateto, angulo);
            Console.WriteLine("El valor del cateto A es: " + triangulo.ObtenerCatetoA().ToString());
            Console.WriteLine("El valor del cateto B es: " + triangulo.ObtenerAnguloOPuestoB().ToString());
            Console.WriteLine("El valor de la hipotenusa es: " + triangulo.ObtenerHipotenusa().ToString());
            Console.WriteLine("El valor del angulo opuesto A es: " + triangulo.ObtenerAnguloOPuestoA().ToString());
            Console.WriteLine("El valor del angulo opuesto B es: " + triangulo.ObtenerAnguloOPuestoB().ToString());
            Console.WriteLine("El valor del area: " + triangulo.ObtenerArea().ToString());
            Console.ReadKey();
        }
    }
}