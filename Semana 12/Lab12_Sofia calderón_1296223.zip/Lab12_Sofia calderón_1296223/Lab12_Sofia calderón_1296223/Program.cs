﻿
using System;

namespace lab_semana12
{
    class Circulo
    {
        private double radio;

        public Circulo(double radio)
        {
            this.radio = radio;
        }
        private double ObtenerPerimetro()
        {
            //Perimetro de la circunferencia
            return 2 * Math.PI * radio;
        }
        private double ObtenerArea()
        {
            // Area de la circuenferencia
            return Math.PI * radio * radio;
        }
        private double ObtenerVolumen()
        {
            // Volumen de una esfera
            return (4 * Math.PI * radio * radio * radio) / 3;
        }

        public void CalcularGeometriadelcirculo(ref double perimetro, ref double area, ref double volumen)
        {
            perimetro = ObtenerPerimetro();
            area = ObtenerArea();
            volumen = ObtenerVolumen();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio del círculo: ");
            double radio = Convert.ToDouble(Console.ReadLine());

            Circulo objCirculo = new Circulo(radio);

            double Sperimetro = 0, Sarea = 0, Svolumen = 0;
            objCirculo.CalcularGeometriadelcirculo(ref Sperimetro, ref Sarea, ref Svolumen);

            Console.WriteLine("Perímetro: " + Sperimetro);
            Console.WriteLine("Área: " + Sarea);
            Console.WriteLine("Volumen: " + Svolumen);
        }
    }
}
