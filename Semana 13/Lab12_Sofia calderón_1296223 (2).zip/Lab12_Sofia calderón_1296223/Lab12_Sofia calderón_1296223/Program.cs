﻿using System;

class Program
{
    static void Main()
    {
        int[] arreglo = new int[10];
        for (int i = 0; i < arreglo.Length; i++)
        {
            Console.Write("Ingresa el número {0}: ", i + 1);
            if (int.TryParse(Console.ReadLine(), out int numero))
            {
                arreglo[i] = numero;
            }  
        }
        int peque = arreglo[0];
        int grande = arreglo[0];
        int suma = 0;
        foreach (int numero in arreglo)
        {
            suma += numero;
            if (numero < peque)
                peque = numero;
            if (numero > grande)
                grande = numero;
        }

        Console.WriteLine("El número más pequeño es: " + peque);
        Console.ReadLine();
        Console.WriteLine("El número más grande es: " + grande);
        Console.ReadLine();
        Console.WriteLine("La suma total de todos los números es: " + suma);
        Console.ReadLine();
        Console.WriteLine("Números ingresados ordenados por posición:");
        Console.ReadLine();

        for (int i = 0; i < arreglo.Length; i++)
        {
            Console.WriteLine("Posición {0}: {1}", i, arreglo[i]);
            
        }
        Console.ReadLine();
        Console.WriteLine("Números ordenados de la ultima posición hasta la primera:");
        Console.ReadLine();
        for (int i = arreglo.Length - 1; i >= 0; i--)
        {
            Console.WriteLine("Posición {0}: {1}", i, arreglo[i]);
        }
        Console.ReadLine();
        double promedio = (double) suma/arreglo.Length;
        Console.WriteLine("El promedio de los números es: " + promedio);
        Console.ReadLine();

        int sumapares = 0;
        int sumaimpares = 0;
        for (int i = 0; i < arreglo.Length; i++)
        {
            if (i % 2 == 0)
                sumapares += arreglo[i];
            else
                sumaimpares += arreglo[i];
        }
        Console.WriteLine("La suma de posiciones pares es: " + sumapares);
        Console.ReadLine();
        Console.WriteLine("La suma de posiciones impares es: " + sumaimpares);
    }
}
