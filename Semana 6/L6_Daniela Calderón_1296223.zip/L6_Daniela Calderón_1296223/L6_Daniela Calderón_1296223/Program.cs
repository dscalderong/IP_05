﻿namespace L6_Daniela_Calderón_1296223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1: operaciones aritmeticas");
            double snumero1, Snumero2, Suma, Resta, Multi, divi;

            Console.WriteLine("ingrese el primer numero: ");
            snumero1 = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("ingrese el segundo numero: ");
            Snumero2 = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Suma = snumero1 + Snumero2;
            Console.Write("El resultado de la suma es: " + Suma);
            Console.WriteLine("");

            Resta = snumero1 - Snumero2;
            Console.Write("El resultado de la resta es: " + Resta);
            Console.WriteLine("");

            Multi = snumero1 * Snumero2;
            Console.Write("El resultado de la multiplicacion es: " + Multi);
            Console.WriteLine("");

            divi = snumero1 / Snumero2;
            Console.Write("El resultado de la division es: " + divi);
            Console.WriteLine("");

            Console.WriteLine("Ejercicio 3: jerarquia de operaciones");
            double a, b, c, bc, raiz, x1, x2, inciso1, inciso2, inciso3, inciso4;

            Console.WriteLine("ingrese el primer numero: ");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("ingrese el segundo numero: ");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("ingrese el tercer numero: ");
            c = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            inciso1 = a * b + c;
            Console.Write("El resultado de la operación 1 es: " + inciso1);
            Console.WriteLine("");

            inciso2 = a * (b + c);
            Console.Write("El resultado de la operación 2 es: " + inciso2);
            Console.WriteLine("");

            inciso3 = a / (b * c);
            Console.Write("El resultado de la operación 3 es: " + inciso3);
            Console.WriteLine("");

            inciso4 = (3 * a + 2 * b) / (Math.Pow(c, 2));
            Console.Write("El resultado de la operación 4 es: " + inciso4);
            Console.WriteLine("");

            bc = b * b;
            raiz = bc - 4 * a * c;
                x1 = bc + (Math.Pow(raiz, 1/2 )) / 2 * a;
                x2 = bc - (Math.Pow(raiz, 1 / 2)) / 2 * a;
            Console.Write("El resultado de la operación 5 es: " + x1 + " y " + x2 );
            Console.WriteLine("");

            Console.WriteLine("GRACIAS PO USAR ESTE PROGRAMA, ADIOS!!");
            Console.WriteLine("");

            Console.ReadKey();
        }
    }
}