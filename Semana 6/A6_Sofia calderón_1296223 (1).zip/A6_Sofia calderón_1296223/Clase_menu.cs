﻿using System.Linq.Expressions;

class Clase_menu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Programa de inventario de ventas de cosmeticos por catalogo");
        Console.WriteLine();
        Console.WriteLine("Seleccione opción");
        Console.WriteLine();
        Console.WriteLine("Menu de cosmeticos en inventario");
        Console.WriteLine("1. Labiales");
        Console.WriteLine("2. Rimel");
        Console.WriteLine("3. Rugor");
        Console.WriteLine("4. Sombras");
        Console.WriteLine("5. Rizador de pestañas");
        Console.WriteLine("6. Delineador");

        String opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine("Selecciono una opcion " + opcion + "Labiales");
                break;
            case "2":
                Console.WriteLine("Selecciono una opcion " + opcion + "Rimel");
                break;
            case "3":
                Console.WriteLine("Selecciono una opcion " + opcion + "Rugor");
                break;
            case "4":
                Console.WriteLine("Selecciono una opcion " + opcion + "sombras");
                break;
            case "5":
                Console.WriteLine("Selecciono una opcion " + opcion + "Rizador de pestañas");
                break;
            case "6":
                Console.WriteLine("Selecciono una opcion " + opcion + "Delineador");
                break;
            

        }
        Console.WriteLine("Selecciono una opcion " + opcion);
        Console.ReadKey();


    }







}
