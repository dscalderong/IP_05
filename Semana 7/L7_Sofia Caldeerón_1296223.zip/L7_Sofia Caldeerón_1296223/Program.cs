﻿// See https://aka.ms/new-console-template for more information
using System;

Console.WriteLine("Bienvenido");
Console.WriteLine("Ejercicio 1");
double snumero1;

Console.WriteLine("ingrese un numero entero: ");
snumero1 = double.Parse(Console.ReadLine());
Console.WriteLine("");

     if (snumero1 > 0)
     {
          Console.WriteLine("Resultado: El entero es positivo" );
     }
     else if(snumero1 < 0)
     {
    Console.WriteLine("Resultado: El entero es negativo");
     }
     else
     {
    Console.WriteLine();
    Console.WriteLine("Resultado: El entero es igual a 0");
      }
Console.WriteLine("");

Console.WriteLine("Ejercicio 2");
Console.WriteLine("");
Console.WriteLine("1. Lunes");
Console.WriteLine("2. martes");
Console.WriteLine("3. miercoles");
Console.WriteLine("4. jueves");
Console.WriteLine("5. viernes");
Console.WriteLine("6. sabado");
Console.WriteLine("7. domingo");
double diasdelasemana;

Console.WriteLine("ingrese un numero del dia de la semana ");
diasdelasemana = double.Parse(Console.ReadLine());
Console.WriteLine("");


      if (diasdelasemana > 7)
      {
    Console.WriteLine("Error el numero debe estar contenido entre 1 y 7");
      }
      else if (diasdelasemana < 1)
      {
     Console.WriteLine("Error el numero a ingresar debe estar contenido entre 1 y 7");
      }
      Console.WriteLine("");
{
    if (diasdelasemana == 1)
    {
        Console.WriteLine("Dia lunes");
    }
    if (diasdelasemana == 2)
    {
        Console.WriteLine("Dia martes");
    }
    if (diasdelasemana == 3)
    {
        Console.WriteLine("Dia miercoles");
    }
    if (diasdelasemana == 4)
    {
        Console.WriteLine("Dia jueves");
    }
    if (diasdelasemana == 5)
    {
        Console.WriteLine("Dia viernes");
    }
    if (diasdelasemana == 6)
    {
        Console.WriteLine("Dia sabado");
    }
    if (diasdelasemana == 7)
    {
        Console.WriteLine("Dia domingo");
    }
}


    