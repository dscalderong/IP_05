﻿class proyec
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo Programa");
        string snombre, sedad, scarrera,scarne;

        Console.WriteLine("ingrese nombre: ");
        snombre = Console.ReadLine();

        Console.WriteLine("ingrese edad: ");
        sedad = Console.ReadLine();

        Console.WriteLine("ingrese Carrera: ");
        scarrera = Console.ReadLine();

        Console.WriteLine("ingrese Carne: ");
        scarne = Console.ReadLine();

        Console.WriteLine("Mi segundo Programa");
        Console.WriteLine("nombre: " + snombre);
        Console.WriteLine("edad: " + sedad);
        Console.WriteLine("carrera: " + scarrera);
        Console.WriteLine("carne: " + scarne);

        Console.Write("soy " + snombre + ",tengo " + sedad + " años y estudio la carrera de " + scarrera + "mi numero de carne es " + scarne);


        Console.ReadKey();

       

    }

}


