﻿class proyec
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string nombre = Console.ReadLine(); 

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy" +  nombre);

        /* este es un ejemplo de 
         * comentario en varias lienas*/

        //este es un ejemplo de comentario en una linea

        Console.Write("Hola Mundo ");
        Console.Write("soy " + nombre);
        Console.ReadKey();

    }

}
  
