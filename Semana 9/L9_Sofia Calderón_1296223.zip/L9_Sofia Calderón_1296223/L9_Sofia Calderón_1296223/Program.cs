﻿
class Program
{
        static void Main(string[] args)

        {
        double montodecompra;
        double descuento = 0.00;

        Console.WriteLine("Bienvenido a los descuentos");
        Console.ReadLine();
        Console.WriteLine("Ingrese el monto de su compra en Q 0.00 ");
        string input = Console.ReadLine();

            if (string.IsNullOrEmpty(input))
            {
            Console.WriteLine("Error: No ingresaste un monto.");
            }
            else 
            {
                Console.WriteLine("Error: El valor ingresado no es un monto válido.");
            }

            if (double.TryParse(Console.ReadLine(), out montodecompra))
            {
            if (montodecompra < 400)
            {
                //aqui no hay descuento
            }
            else if (montodecompra <= 1000)
            {
                descuento = montodecompra * 0.07;
            }
            else if (montodecompra <= 5000)
            {
                descuento = montodecompra * 0.10;
            } 
            else if (montodecompra <= 15000)
            {
                descuento = montodecompra * 0.15;
            }
            else
            {
                descuento = montodecompra * 0.25;
            }

            Console.WriteLine("¿Usted posse un codigo de descuento? Si ó No ");
            Console.WriteLine("1. Si");
            Console.WriteLine("2. No");
            Console.WriteLine();
            double montoFinal = Convert.ToInt32(Console.ReadLine());


            if (montoFinal == 1)
            {
                montoFinal = montodecompra - (descuento + montodecompra * 0.05);
                Console.WriteLine("El monto a pagar es de Q" + montoFinal); 
                Console.WriteLine("");
            }
            else if (montoFinal == 2)
            {
                montoFinal = montodecompra - descuento;
                Console.WriteLine("El monto a pagar es de Q" + montoFinal);
                Console.WriteLine("");
            }



            }
        }
}



